-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i9b101.p.ssafy.io    Database: WaterBell
-- ------------------------------------------------------
-- Server version	8.0.34-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `facility`
--

DROP TABLE IF EXISTS `facility`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facility` (
  `facility_id` int NOT NULL AUTO_INCREMENT,
  `gugun_id` int NOT NULL,
  `is_apart` tinyint(1) NOT NULL,
  `first_flood_message` varchar(225) NOT NULL COMMENT '1차 침수 알림/LED 메시지',
  `activation_message` varchar(225) NOT NULL COMMENT '차수판 동작 알림/LED 동작 메시지',
  `deactivation_message` varchar(225) NOT NULL COMMENT '차수판 해제 알림/LED 해제 메시지',
  `first_alarm_value` int NOT NULL COMMENT '1차 수위 기준치',
  `second_alarm_value` int NOT NULL COMMENT '2차 수위 기준치',
  `hub_ip` varchar(30) NOT NULL COMMENT '연결된 허브 주소',
  `status` varchar(10) NOT NULL COMMENT '정상(Default)/1차/ 2차,/작동 상태',
  PRIMARY KEY (`facility_id`),
  KEY `FK_gugun_TO_facility_1` (`gugun_id`),
  CONSTRAINT `FK_gugun_TO_facility_1` FOREIGN KEY (`gugun_id`) REFERENCES `gugun` (`gugun_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facility`
--

LOCK TABLES `facility` WRITE;
/*!40000 ALTER TABLE `facility` DISABLE KEYS */;
INSERT INTO `facility` VALUES (1,52,0,'            ','진입금지','진입금지 해제',15,30,'192.168.0.2','SECOND'),(2,36,0,'침수경고 현재수위:15mm 이상','진입금지','진입금지 해제',15,30,'192.168.0.2','WORKING'),(3,36,0,'침수경고 현재수위:15mm 이상','진입금지','진입금지 해제',15,30,'192.168.0.2','WORKING'),(4,36,0,'침수경고 현재수위:15mm 이상','진입금지','진입금지 해제',15,30,'192.168.0.2','WORKING'),(5,36,0,'침수경고 현재수위:15mm 이상','진입금지','진입금지 해제',15,30,'192.168.0.2','WORKING'),(6,68,0,'침수경고 현재수위:15mm 이상','진입금지','진입금지 해제',15,30,'192.168.0.2','WORKING'),(7,52,0,'침수경고 현재수위:15mm 이상','진입금지','진입금지 해제',15,30,'192.168.0.2','WORKING'),(8,20,0,'침수경고 현재수위:15mm 이상','진입금지','진입금지 해제',15,30,'192.168.0.2','WORKING'),(9,20,0,'침수경고 현재수위:15mm 이상','진입금지','진입금지 해제',15,30,'192.168.0.2','SECOND'),(10,3,0,'침수경고 현재수위:15mm 이상','진입금지','진입금지 해제',15,30,'172.20.10.8','WORKING'),(11,52,1,'[WaterBell]주의: 지하주차장의 수위가 1차 경고 기준치에 도달했습니다. 주차장에 차량을 주차하신 분들은 가능한 빠르게 차량을 지상으로 이동시켜 주시기 바랍니다.','[WaterBell]차수판이 작동되었습니다. 지하 주자장 내 차량을 이동하시던 분들은 정차하시고 주차장 밖으로 나와주시길 바랍니다.','[WaterBell]차수판 동작이 해제되었습니다. 차량 이동이 가능하나 주차장이 혼잡할 수 있으니 천천히 출차 바랍니다.',10,20,'192.168.0.1','WORKING'),(12,52,1,'[WaterBell]주의: 지하주차장의 수위가 1차 경고 기준치에 도달했습니다. 주차장에 차량을 주차하신 분들은 가능한 빠르게 차량을 지상으로 이동시켜 주시기 바랍니다.','[WaterBell]차수판이 작동되었습니다. 지하 주자장 내 차량을 이동하시던 분들은 정차하시고 주차장 밖으로 나와주시길 바랍니다.','[WaterBell]차수판 동작이 해제되었습니다. 차량 이동이 가능하나 주차장이 혼잡할 수 있으니 천천히 출차 바랍니다.',10,20,'192.168.0.1','WORKING');
/*!40000 ALTER TABLE `facility` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-17 21:44:34
