-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i9b101.p.ssafy.io    Database: WaterBell
-- ------------------------------------------------------
-- Server version	8.0.34-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` int NOT NULL AUTO_INCREMENT,
  `login_id` varchar(50) NOT NULL,
  `password` varchar(225) NOT NULL,
  `created_at` datetime NOT NULL,
  `state` tinyint(1) NOT NULL COMMENT '활성 : true,  비활성: false',
  `role` varchar(15) NOT NULL COMMENT 'apart_member / apart_manager/ public_manager / system',
  `expired_at` datetime DEFAULT NULL,
  `phone` varchar(11) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'system','system','2023-08-03 00:45:11',1,'SYSTEM',NULL,'01073877808'),(2,'asdf1234','{bcrypt}$2a$10$JEjA1jSlmRnWNaPpAx8/3u2gMZOvH59nHku.39rrGHDCZLF7/I5cC','2023-08-03 00:45:11',1,'APART_MEMBER',NULL,'01086461926'),(3,'qwer1234','{bcrypt}$2a$10$TwE2fJqxInZTLXG0zRNPfuh//pfhkkRFrVpIK/zcLq4nKul/yMq9a','2023-08-03 00:45:11',1,'APART_MEMBER',NULL,'01088742165'),(4,'zxcv1234','{bcrypt}$2a$10$Bno2mqwG9PYSM7F49cm7uuI1pkpo/EOol81RoMYys1sT2gvDYHfR.','2023-08-03 00:45:11',0,'USER','2023-08-16 10:03:35','01073402210'),(5,'aManager1','{bcrypt}$2a$10$Tzkt1iLHjO5qlslPfErVZu9ahoK7bcpX9GfpN2Js7oJT2P2XulKKO','2023-08-03 00:45:11',1,'APART_MANAGER',NULL,'01073877808'),(6,'aManager2','{bcrypt}$2a$10$Tzkt1iLHjO5qlslPfErVZu9ahoK7bcpX9GfpN2Js7oJT2P2XulKKO','2023-08-03 00:45:11',1,'APART_MANAGER',NULL,'01012345678'),(7,'pManager1','{bcrypt}$2a$10$Tzkt1iLHjO5qlslPfErVZu9ahoK7bcpX9GfpN2Js7oJT2P2XulKKO','2023-08-03 00:45:11',1,'PUBLIC_MANAGER',NULL,'01073402210'),(8,'y635712','{bcrypt}$2a$10$mytVOqXZxbnIcRS.ZRE2c.3VgO1QkbE7HAVRg5Y3otFoKTYD3Haei','2023-08-10 08:46:33',1,'APART_MEMBER',NULL,'01071797299'),(9,'gyrud0482','{bcrypt}$2a$10$BLhXvktjminue7XXmd1CAeDdjYv3Cmrzm3CoHjOt/2WOAOsR2W6qS','2023-08-14 13:35:04',1,'USER',NULL,'01086461926'),(10,'zxcv123','{bcrypt}$2a$10$ayyTIVmDCiqGNZ0cATS8yO3BrmdQCQxjPg7sSBmuhwA/DEBg/pY2G','2023-08-16 10:18:54',0,'USER','2023-08-16 10:41:40','01073402210'),(11,'zxcv12','{bcrypt}$2a$10$5L0zBlosDM8.Io.fEaYE8utt5MaewpxvCTgD6ea19WwKN5OSjMOJe','2023-08-16 10:46:28',0,'USER','2023-08-16 10:48:14','01073402210'),(12,'zxcv1','{bcrypt}$2a$10$q6EfhqS8u0QVlgREKN0sw.2zNPgO6KF1FsyLKOAUQRwFlj5QCZSEi','2023-08-16 10:50:07',0,'USER','2023-08-16 10:50:25','01073402210'),(13,'zxcv','{bcrypt}$2a$10$tLT6SLnOxEhHxK/FestULe6B0Gj6jksauAcX.3ebY6Ft.xBD0jSfO','2023-08-16 10:52:30',0,'USER','2023-08-16 12:21:31','01073402210'),(15,'y6357@naver.com','{bcrypt}$2a$10$r3KLbauoqPvrUZMFbjyzr.rZzNs/Jxcr2tx6pr0HaoPylIo/plPzO','2023-08-17 09:29:47',1,'APART_MEMBER',NULL,'01064723285'),(16,'gyrud04822@naver.com','{bcrypt}$2a$10$aEqb96FcJa2DCOQ87x6CvOgfu8b7Rtp0x25LBRq8r7ud.yAXn6MSG','2023-08-17 09:48:30',1,'USER',NULL,'01023781926'),(17,'0909top@naver.com','{bcrypt}$2a$10$tqSE9Vbsp6ckH4NOQ11ipOPa8xnKo5noLw8CYN7uDP3PYq/Q1mvlu','2023-08-17 13:18:40',0,'USER','2023-08-17 15:41:07','01073402210'),(18,'zxcv12345','{bcrypt}$2a$10$dqoCYq1gP9U4CDfCZvHugO42ephBOEUExOxwUe1IZvtrpKFTWHQ1S','2023-08-17 16:38:56',1,'APART_MEMBER',NULL,'01073402210'),(19,'gyrud0482@naver.com','{bcrypt}$2a$10$NJWPN963tD8TSO42NQXYU.12t2tlyvFAvcxCKwViWpcV5dJw8kyU6','2023-08-17 20:47:42',1,'APART_MEMBER',NULL,'01023781926');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-17 21:44:34
