-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i9b101.p.ssafy.io    Database: WaterBell
-- ------------------------------------------------------
-- Server version	8.0.34-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `image` (
  `image_id` int NOT NULL AUTO_INCREMENT,
  `apart_board_id` int DEFAULT NULL,
  `underground_road_board_id` int DEFAULT NULL,
  `image_name` varchar(50) NOT NULL,
  `image_path` varchar(225) NOT NULL,
  PRIMARY KEY (`image_id`),
  KEY `FK_underground_road_board_TO_image` (`underground_road_board_id`),
  KEY `FK_apart_board_TO_image_1` (`apart_board_id`),
  CONSTRAINT `FK_apart_board_TO_image_1` FOREIGN KEY (`apart_board_id`) REFERENCES `apart_board` (`board_id`),
  CONSTRAINT `FK_underground_road_board_TO_image` FOREIGN KEY (`underground_road_board_id`) REFERENCES `underground_road_board` (`board_id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
INSERT INTO `image` VALUES (1,1,NULL,'주차장 침수.jpg','0bdd050b-1d34-4ae0-aceb-364944123803.jpg'),(2,NULL,1,'지하차도 침수.jpg','a0c92920-fecd-4d70-8aee-b0df37e4e58a.jpg'),(3,NULL,2,'지하차도 침수위험.gif','435a91b2-b414-4ea9-ae8c-f7983a53741d.gif'),(4,NULL,8,'비 그침.jpg','27639285-fc72-456b-9d07-5acd5bac4e4f.jpg'),(5,NULL,15,'비 그침.jpg','dca1f35c-49ff-40b2-84b9-2c6a555c4358.jpg'),(9,NULL,164,'지하차도.jpg','9bc6747c-e4d5-4b19-a232-b6e73927e321.jpg'),(10,NULL,165,'지하주차장 차수벽.jpg','9b743126-991a-49db-b5c0-315b8cea57bd.jpg'),(11,NULL,165,'지하차도.jpg','c7025a4f-415c-40ae-832c-22fcf3ad5fdc.jpg'),(12,NULL,167,'상단 배너 1.png','a2bdf9bf-d1b7-4689-8bfd-01074c30bac6.png'),(28,NULL,181,'지하주차장 차수벽.jpg','aed82289-4cd9-4a8c-b7cb-08103864d78b.jpg'),(34,NULL,183,'지하차도.jpg','eca7e03b-68f5-470b-b3ad-34c8bf6ebce8.jpg'),(42,NULL,188,'지하주차장 차수벽.jpg','4b4afecd-44e3-4fe5-a0e1-0292f34de0ee.jpg'),(43,NULL,188,'지하차도.jpg','14c96685-624b-4929-94f0-e982794a37ad.jpg'),(44,3,NULL,'지하주차장 차수벽.jpg','6c25ad23-ca1f-4ffc-ba2d-0518b41e313e.jpg'),(45,4,NULL,'지하주차장 차수벽.jpg','45857e7e-9602-4528-ae13-6452289cf0d1.jpg'),(46,5,NULL,'지하주차장 차수벽.jpg','dcd737ca-b58d-44bc-820d-528acde6b36a.jpg'),(47,5,NULL,'지하차도.jpg','876ed1cd-b3e0-4709-bae6-a52aaad949be.jpg'),(48,3,NULL,'지하차도.jpg','0600d8dc-243f-491c-bf7e-e0f5d13abf62.jpg'),(49,5,NULL,'상단 배너 1.png','f13053e3-efe0-466e-9449-5f6bb3a612f2.png'),(50,6,NULL,'대시보드 1.png','9c460b73-523a-48d6-86c0-9d2b56e992aa.png'),(51,6,NULL,'상단 배너 3.png','c720502f-243e-46eb-9340-088caea425d0.png'),(57,8,NULL,'비 그침.jpg','7e95d529-34ea-4c70-b003-3fadb874b13a.jpg'),(61,15,NULL,'지하주차장 차수벽.jpg','d34fc5d3-adf8-4bde-8cd0-9e41b17357aa.jpg'),(62,16,NULL,'비 그침.jpg','57c5ea1a-f4a8-4aec-874a-5cc7d7116b65.jpg'),(67,22,NULL,'지하주차장 차수벽.jpg','50e6985a-55cf-4a17-8886-609b71b2ab13.jpg'),(68,22,NULL,'지하차도.jpg','a907c8ad-4169-409e-887b-9fb63df5679f.jpg'),(69,24,NULL,'3642ccc2-e81f-498e-aec4-632e5055894a.png','cf334959-6ec7-43df-acc9-28200674d362.png'),(74,34,NULL,'비 그침.jpg','a440f102-99b9-497c-b885-1bc6bb381688.jpg'),(75,NULL,194,'지하차도.jpg','35968427-ac67-40c1-9c31-aeea5a9b2ef1.jpg'),(76,NULL,195,'상단 배너 3.png','06a486a0-52b0-425a-812c-f88bf4746641.png'),(77,NULL,195,'지하주차장 차수벽.jpg','b4c61fe6-fd2f-45f8-9633-e4a160a1fb42.jpg'),(78,NULL,195,'지하차도.jpg','b598b07f-9a2e-46fe-b494-ca8d1e77fb3f.jpg'),(79,NULL,196,'지하차도.jpg','8db4ae8d-d270-4759-bef5-a232b4c7743d.jpg'),(80,NULL,196,'지하주차장 차수벽.jpg','b4373bf5-504a-4169-8f9e-8109775c6d8d.jpg'),(81,NULL,203,'포기를모르는남자.jpg','d2fc2aa1-3976-4aa3-bb74-e64fbb547ad5.jpg'),(82,NULL,204,'Siren_green.png','47270ac3-dd38-4ff0-befd-cc7691982166.png'),(83,NULL,205,'Siren_green.png','0a164e35-63fd-43e1-bd7d-6cf72e33e44d.png'),(84,NULL,205,'Siren_orange.png','cfd69309-d338-4d96-8cc3-4af016935aa9.png'),(85,NULL,205,'Siren_red.png','ac09694d-d6a6-48ac-800d-51403f780504.png'),(87,NULL,210,'지하주차장1.jpg','dac4a7de-6f09-41c4-bf0d-06cf8f12fb21.jpg'),(89,NULL,211,'지하주차장 차수벽.jpg','6b6a5de1-43ff-4b88-9af3-d13e0e72b289.jpg'),(90,NULL,211,'지하차도.jpg','e2ccbb73-2f92-499f-9030-8dd254b01767.jpg'),(91,2,NULL,'지하주차장 차수벽.jpg','24b89eaa-61cb-422f-9205-f7534d4b0b8b.jpg'),(100,NULL,187,'지하주차장 차수벽.jpg','9010e866-e9ae-4d52-b101-07d5cbb3a47f.jpg'),(102,NULL,187,'지하차도.jpg','f588db89-5df1-47cd-8c99-52cf55ef6a65.jpg'),(109,NULL,212,'대시보드 1.png','f04d8edf-8f71-441d-9263-355d7564eecc.png'),(110,NULL,212,'메인 화면 1.png','118d81ae-3f33-45c7-ba94-cde823ddb258.png'),(112,NULL,212,'지하차도.jpg','36d11875-0f20-4de7-98f1-e1dbb841c847.jpg'),(123,NULL,213,'지하주차장 차수벽.jpg','7cdaa230-7c0b-4dae-b640-f2ed17229b91.jpg'),(124,NULL,213,'지하차도.jpg','2bb314de-abbe-444d-b244-bea1d8f50564.jpg'),(127,40,NULL,'지하주차장 차수벽.jpg','3ee0a45b-1477-435e-9a9f-78b0f4fbc50b.jpg'),(128,41,NULL,'차수판 작동 중.jpg','ded3a1c1-297e-4320-80a3-f2679a77c907.jpg'),(132,44,NULL,'지하차도.jpg','faf97b50-be02-423f-aeab-6329f5f1ac94.jpg'),(133,44,NULL,'파비콘 1.png','5b95df84-530d-447a-a0a9-96c72a89e022.png'),(134,NULL,214,'지하주차장 차수벽.jpg','a13a7e36-b397-4208-8459-232b0ac0b4ba.jpg'),(136,46,NULL,'지하차도.jpg','7739600f-a6e5-495c-98fd-60af5412f381.jpg'),(137,NULL,215,'차수판 작동 중.jpg','20c5fd23-657b-4e01-b0bb-f3e803bcc1a0.jpg'),(138,NULL,216,'지하차도.jpg','c936ab3e-dfc5-4353-ad8f-62b007da04e0.jpg'),(139,NULL,181,'지하차도.jpg','bbc7fb3b-c462-4eb3-b84e-3e69114a6058.jpg');
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-17 21:44:26
