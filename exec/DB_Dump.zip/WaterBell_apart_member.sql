-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i9b101.p.ssafy.io    Database: WaterBell
-- ------------------------------------------------------
-- Server version	8.0.34-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apart_member`
--

DROP TABLE IF EXISTS `apart_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apart_member` (
  `member_id` int NOT NULL,
  `facility_id` int NOT NULL,
  `is_system` tinyint(1) NOT NULL COMMENT 'SYSTEM -true/ SOCIAL-false',
  `platform_type` varchar(6) DEFAULT NULL COMMENT 'KAKAO, NABER, GOOGLE',
  `name` varchar(10) NOT NULL,
  `address_number` int DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  KEY `FK_apart_TO_apart_member_1` (`facility_id`),
  CONSTRAINT `FK_apart_TO_apart_member_1` FOREIGN KEY (`facility_id`) REFERENCES `apart` (`facility_id`),
  CONSTRAINT `FK_member_TO_apart_member_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apart_member`
--

LOCK TABLES `apart_member` WRITE;
/*!40000 ALTER TABLE `apart_member` DISABLE KEYS */;
INSERT INTO `apart_member` VALUES (2,11,1,NULL,'이효경',302),(3,11,1,NULL,'조준희',201),(4,11,1,NULL,'황종인',101),(8,11,1,NULL,'황윤영',102),(9,11,1,NULL,'효경효경',302),(10,11,1,NULL,'황종인',101),(11,11,1,NULL,'황종인',101),(12,11,1,NULL,'황종인',101),(13,11,1,NULL,'황종인',102),(15,11,0,'NAVER','황윤영',301),(16,11,0,'NAVER','이효경',502),(17,11,0,'NAVER','황종인',102),(18,11,1,NULL,'황종인',104),(19,11,0,'NAVER','이효경',802);
/*!40000 ALTER TABLE `apart_member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-17 21:44:28
