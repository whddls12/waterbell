-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: i9b101.p.ssafy.io    Database: WaterBell
-- ------------------------------------------------------
-- Server version	8.0.34-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apart_board`
--

DROP TABLE IF EXISTS `apart_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apart_board` (
  `board_id` int NOT NULL AUTO_INCREMENT,
  `facility_id` int NOT NULL,
  `member_id` int NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `status` varchar(15) NOT NULL COMMENT '1. 처리전 2.  처리중 3. 처리완료',
  `create_date` datetime NOT NULL,
  `view_count` int NOT NULL,
  PRIMARY KEY (`board_id`),
  KEY `FK_apart_TO_apart_board_1` (`facility_id`),
  KEY `FK_apart_member_TO_apart_board_1` (`member_id`),
  CONSTRAINT `FK_apart_member_TO_apart_board_1` FOREIGN KEY (`member_id`) REFERENCES `apart_member` (`member_id`),
  CONSTRAINT `FK_apart_TO_apart_board_1` FOREIGN KEY (`facility_id`) REFERENCES `apart` (`facility_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apart_board`
--

LOCK TABLES `apart_board` WRITE;
/*!40000 ALTER TABLE `apart_board` DISABLE KEYS */;
INSERT INTO `apart_board` VALUES (1,11,3,'지하주자창 빗물 차오','지하주차장에 빗물이 계속 들어와요, 빨리 조치를 취해주세요!','BEFORE','2023-08-03 09:46:51',5),(2,11,3,'문자 경고 받았는데, 비가 많이 오네요! 차수판 올려주세요','주차장에서 출차하라는 문자를 받았는데요, 비가 너무 많이와서 차빼러 가기 힘들것 같아요!, 차수판 올려주세요!','BEFORE','2023-08-03 09:50:11',11),(3,11,4,'지하주차장 신고접수','바퀴잠기기 직전이에ㅛ!','BEFORE','2023-08-15 13:54:55',23),(4,11,4,'휴대폰번호, 이름','넘어가나?','BEFORE','2023-08-15 15:14:27',13),(5,11,4,'123','123','BEFORE','2023-08-15 15:22:23',20),(6,11,4,'상세페이지로 바로이동?','123','COMPLETE','2023-08-15 16:01:59',21),(8,11,2,'비가 많이 와서 너무 위험해요!','비가 많이 와서 너무 위험해요! 주차장 출차 안내를 해야할 것 같아요!','COMPLETE','2023-08-15 17:09:18',26),(14,12,4,'123','123','BEFORE','2023-08-15 22:23:11',2),(15,12,4,'123','123','BEFORE','2023-08-15 22:23:31',26),(16,11,2,'비가 많이 와서 너무 위험해요!','비가 많이 와서 너무 위험해요! 주차장 출차 안내를 해야할 것 같아요!','COMPLETE','2023-08-15 22:23:58',9),(22,11,4,'작성 후 바로 이동 테스트','성공성공~','PROCESSING','2023-08-16 02:19:03',59),(23,12,2,'지하주차장 빗물 유입 신고','지하주차장에 빗물 유입이 너무 많아, 곧 침수가 유려됩니다.\r\n직접 확인해보시고 차주판 동작 요청드립니다.\r\n감사합니다','BEFORE','2023-08-16 03:55:48',2),(24,12,2,'123','123','BEFORE','2023-08-16 03:56:07',6),(29,11,2,'신고 접수 합니다','지하주차장에 물이 계속 유입되고 있어요! 빨리 조치 부탁드립니다.\r\n이미 바퀴가 점점 잠기고 있어요!','PROCESSING','2023-08-16 14:24:13',5),(30,11,2,'지하 주차장에 출차 알림 요청','태풍으로 인해 비가 너무 많이 오고 있어요, \r\n밤 시간이라 더 늦으면 출차가 힘들 것 같아요, 미리 출차 안내 해주시면  좋을 것 같습니다.\r\n','PROCESSING','2023-08-16 14:25:41',6),(31,11,2,'차수판 작동 요청','1차 경고 알림을 받았는데요,,,, 이미 비가 너무 많이 유입되서 빨리 차수판을 동작하는것이 좋을 것 같아요','PROCESSING','2023-08-16 14:27:27',8),(32,11,2,'차수판 작동이 시급합니다!!','빗물 유입 속도가 빨라서 출차 안내보다는 빨리 차수판을 작동해야할 것 같아요, 빠른 확인 및 조치 요청드립니다.','BEFORE','2023-08-16 14:28:43',7),(33,11,2,'차수판 작동해서 빗물 유입을 빨리 막아주세요','비가 너무 많이 와서 지하주차장 배수가 안됩니다. 차수판 작동해서 빗물 유입을 빨리 막아주세요','BEFORE','2023-08-16 14:33:07',20),(34,11,2,'차수판 해제 요청드립니다.','비가 멈췄네요, 출차할 수 있도록 차수판 작동 해제 요청드립니다.','BEFORE','2023-08-16 14:39:16',44),(40,12,17,'123','123','BEFORE','2023-08-17 15:16:13',2),(41,11,16,'차수판 작동 요청','지하주차장에 물이 점점 차오르는데 배수가 안돼요, 금방 차오를 것 같은데 확인해주세요!!!!','BEFORE','2023-08-17 15:16:26',10),(43,12,16,'신고접수 합니다!','차수판 작동 시켜주세요!!!!!!!!','BEFORE','2023-08-17 15:18:29',3),(44,12,17,'123','123123','BEFORE','2023-08-17 15:19:14',3),(45,11,15,'지금 지하차도에 물이 들어와요','cctv 확인 부탁드립니다','BEFORE','2023-08-17 15:58:05',6),(46,11,18,'지하차도 물찼어요','더많이오면 차수판 올려야 할 것 같습니다!!','BEFORE','2023-08-17 17:49:46',2);
/*!40000 ALTER TABLE `apart_board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-17 21:44:27
